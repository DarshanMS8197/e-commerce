const { test, expect } = require('@playwright/test');

test.describe('Shopping Logic', () => {
  const searchTerms = ['TV', 'Earphones', 'Oven', 'Mixer'];

  for (const term of searchTerms) {
    test(`Search for "${term}" shows correct results`, async ({ page }) => {
      await page.goto('/home.html');
      await page.fill('#nav-search', term);
      const cards = page.locator('.product-card');
      await expect(cards.first()).toContainText(term, { ignoreCase: true });
    });
  }

  test('Adding same item twice increases quantity', async ({ page }) => {
    await page.goto('/product.html?id=1');
    await page.click('#add-to-cart');
    await page.click('#add-to-cart');
    await page.goto('/cart.html');
    await expect(page.locator('.cart-qty span')).toHaveText('2');
  });
});