const { test, expect } = require('@playwright/test');

test.describe('Authentication Suite', () => {
  test('Successful Signup and Redirect', async ({ page }) => {
    await page.goto('/');
    await page.click('button[data-tab="signup"]');
    await page.fill('#signup-email', 'newuser@test.com');
    await page.fill('#signup-password', 'password123');
    await page.click('#signup-form button');
    // Verify redirection to home
    await expect(page).toHaveURL(/home.html/);
  });

  test('Error on short password', async ({ page }) => {
    await page.goto('/');
    await page.click('button[data-tab="signup"]');
    await page.fill('#signup-password', '123');
    await page.click('#signup-form button');
    await expect(page.locator('#signup-password-error')).toBeVisible();
  });
});