const { test, expect } = require('@playwright/test');

test('Payment page requires valid card format', async ({ page }) => {
  // Pre-load cart via LocalStorage
  await page.goto('/');
  await page.evaluate(() => {
    localStorage.setItem('zyphroa_cart', JSON.stringify([{id:'1', title:'TV', price:32999, qty:1}]));
  });
  await page.goto('/payment.html');
  await page.fill('#card-number', '123'); // Invalid
  await page.click('button[type="submit"]');
  await expect(page.locator('#payment-error')).toContainText('valid card number');
});