(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;
  window.zyphroa.renderNav();

  var grid = document.getElementById('products-grid');
  var emptyEl = document.getElementById('products-empty');
  var searchInput = document.getElementById('nav-search');

  function renderProducts(list) {
    if (!list.length) {
      grid.style.display = 'none';
      emptyEl.style.display = 'block';
      return;
    }
    grid.style.display = 'grid';
    emptyEl.style.display = 'none';
    grid.innerHTML = list
      .map(function (p, i) {
        return (
          '<article class="product-card">' +
          '<a href="product.html?id=' +
          encodeURIComponent(p.id) +
          '" class="product-card-image">' +
          '<img src="' +
          p.image +
          '" alt="' +
          p.title.replace(/"/g, '&quot;') +
          '" width="220" height="220" loading="' + (i === 0 ? 'eager' : 'lazy') + '"' + (i === 0 ? ' fetchpriority="high"' : '') + '>' +
          '</a>' +
          '<div class="product-card-body">' +
          '<h2 class="product-card-title">' +
          p.title +
          '</h2>' +
          '<p class="product-card-price">' +
          formatPrice(p.price) +
          '</p>' +
          '<p class="product-card-rating">★ ' +
          p.rating +
          '</p>' +
          '<a href="product.html?id=' +
          encodeURIComponent(p.id) +
          '" class="btn btn-primary">View Details</a>' +
          '</div></article>'
        );
      })
      .join('');
  }

  function filterProducts() {
    var q = (searchInput && searchInput.value.trim().toLowerCase()) || '';
    var list = !q ? PRODUCTS : PRODUCTS.filter(function (p) {
      return (
        p.title.toLowerCase().indexOf(q) !== -1 ||
        (p.genre && p.genre.toLowerCase().indexOf(q) !== -1)
      );
    });
    renderProducts(list);
  }

  filterProducts();
  if (searchInput) {
    searchInput.addEventListener('input', filterProducts);
    searchInput.addEventListener('search', filterProducts);
  }

  var clearBtn = document.getElementById('clear-search');
  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      if (searchInput) searchInput.value = '';
      filterProducts();
    });
  }
})();
