(function () {
  function guard() {
    if (!getCurrentUser()) {
      window.location.href = 'index.html';
      return false;
    }
    return true;
  }

  function renderNav(cartCount) {
    var nav = document.getElementById('main-nav');
    if (!nav) return;
    var count = cartCount !== undefined ? cartCount : getCart().length;
    nav.innerHTML =
      '<a href="home.html" class="nav-brand">Zyphroa</a>' +
      (nav.dataset.search !== undefined
        ? '<div class="search-wrap"><input type="search" placeholder="Search products..." id="nav-search" aria-label="Search products"></div>'
        : '') +
      '<div class="nav-links">' +
      '<a href="home.html">Home</a>' +
      '<a href="cart.html">Cart<span class="nav-cart-count">' + count + '</span></a>' +
      '<a href="orders.html">Orders</a>' +
      '<a href="index.html" id="nav-logout">Logout</a>' +
      '</div>';
    var logout = document.getElementById('nav-logout');
    if (logout) {
      logout.addEventListener('click', function (e) {
        e.preventDefault();
        setCurrentUser(null);
        window.location.href = 'index.html';
      });
    }
  }

  window.zyphroa = {
    guard: guard,
    renderNav: renderNav
  };
})();
