(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;

  var cart = getCart();
  window.zyphroa.renderNav(cart.length);

  var content = document.getElementById('checkout-content');
  var emptyEl = document.getElementById('checkout-empty');

  if (!cart.length) {
    content.style.display = 'none';
    emptyEl.style.display = 'block';
    return;
  }

  var total = cart.reduce(function (sum, item) { return sum + item.price * item.qty; }, 0);

  content.innerHTML =
    '<div class="cart-summary" style="margin-bottom: 1.5rem;">' +
    '<p style="margin-bottom: 0.5rem;"><strong>Order Summary</strong></p>' +
    cart
      .map(function (item) {
        return (
          '<div class="cart-summary-row">' +
          '<span>' + item.title + ' × ' + item.qty + '</span>' +
          '<span>' + formatPrice(item.price * item.qty) + '</span>' +
          '</div>'
        );
      })
      .join('') +
    '<div class="cart-summary-row grand">' +
    '<span>Total</span><span>' + formatPrice(total) + '</span>' +
    '</div></div>' +
    '<form class="checkout-form" id="checkout-form" action="payment.html" method="get">' +
    '<div class="form-group">' +
    '<label for="ship-name">Full Name</label>' +
    '<input type="text" id="ship-name" name="name" required placeholder="John Doe" autocomplete="name">' +
    '</div>' +
    '<div class="form-group">' +
    '<label for="ship-address">Address</label>' +
    '<input type="text" id="ship-address" name="address" required placeholder="Street, City, State, PIN" autocomplete="street-address">' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group">' +
    '<label for="ship-phone">Phone</label>' +
    '<input type="tel" id="ship-phone" name="phone" required placeholder="10-digit mobile" autocomplete="tel">' +
    '</div>' +
    '<div class="form-group">' +
    '<label for="ship-email">Email</label>' +
    '<input type="email" id="ship-email" name="email" value="" readonly placeholder="Email" autocomplete="email">' +
    '</div></div>' +
    '<input type="hidden" name="total" id="checkout-total" value="' + total + '">' +
    '<button type="submit" class="btn btn-primary">Proceed to Payment</button>' +
    '</form>';

  var emailInput = document.getElementById('ship-email');
  var user = getCurrentUser();
  if (emailInput && user) emailInput.value = user;

  document.getElementById('checkout-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var totalVal = document.getElementById('checkout-total').value;
    window.location.href =
      'payment.html?total=' + encodeURIComponent(totalVal);
    return false;
  });
})();
