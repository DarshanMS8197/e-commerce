(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;

  var orders = getOrders();
  window.zyphroa.renderNav();

  var listEl = document.getElementById('orders-list');
  var emptyEl = document.getElementById('orders-empty');

  if (!orders.length) {
    listEl.style.display = 'none';
    emptyEl.style.display = 'block';
    return;
  }

  listEl.innerHTML = orders
    .map(function (order) {
      var date = new Date(order.date);
      var dateStr = date.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      var itemsHtml = (order.items || [])
        .map(function (i) {
          return i.title + ' × ' + i.qty + ' — ' + formatPrice(i.price * i.qty);
        })
        .join(', ');
      return (
        '<div class="order-card">' +
        '<div class="order-card-header">' +
        '<span class="order-id">' + order.id + '</span>' +
        '<span class="order-date">' + dateStr + '</span>' +
        '</div>' +
        '<div class="order-total">' + formatPrice(order.total) + '</div>' +
        '<ul class="order-items">' +
        (order.items || [])
          .map(function (i) {
            return '<li>' + i.title + ' × ' + i.qty + ' — ' + formatPrice(i.price * i.qty) + '</li>';
          })
          .join('') +
        '</ul></div>'
      );
    })
    .join('');
})();
