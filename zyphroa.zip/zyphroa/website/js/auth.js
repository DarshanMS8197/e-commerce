(function () {
  if (getCurrentUser()) {
    window.location.href = 'home.html';
    return;
  }

  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  const tabs = document.querySelectorAll('.auth-tabs button');

  function showError(id, msg) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = msg || '';
      el.style.display = msg ? 'block' : 'none';
    }
  }

  function clearErrors(formId) {
    document.querySelectorAll('#' + formId + ' .form-error').forEach(function (e) {
      e.textContent = '';
      e.style.display = 'none';
    });
  }

  tabs.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const tab = this.getAttribute('data-tab');
      tabs.forEach(function (b) { b.classList.remove('active'); });
      this.classList.add('active');
      loginForm.style.display = tab === 'login' ? 'block' : 'none';
      signupForm.style.display = tab === 'signup' ? 'block' : 'none';
      clearErrors('login-form');
      clearErrors('signup-form');
    });
  });

  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    clearErrors('login-form');
    var email = document.getElementById('login-email').value.trim();
    var password = document.getElementById('login-password').value;
    if (!email) {
      showError('login-email-error', 'Enter your email');
      return;
    }
    if (!password) {
      showError('login-password-error', 'Enter your password');
      return;
    }
    if (!validateLogin(email, password)) {
      showError('login-password-error', 'Invalid email or password');
      return;
    }
    setCurrentUser(email);
    window.location.href = 'home.html';
  });

  signupForm.addEventListener('submit', function (e) {
    e.preventDefault();
    clearErrors('signup-form');
    var email = document.getElementById('signup-email').value.trim();
    var password = document.getElementById('signup-password').value;
    if (!email) {
      showError('signup-email-error', 'Enter your email');
      return;
    }
    if (!password || password.length < 6) {
      showError('signup-password-error', 'Password must be at least 6 characters');
      return;
    }
    if (!saveUser(email, password)) {
      showError('signup-email-error', 'Email already registered');
      return;
    }
    setCurrentUser(email);
    window.location.href = 'home.html';
  });
})();
