(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;

  var cart = getCart();
  window.zyphroa.renderNav(cart.length);

  var container = document.getElementById('cart-items');
  var emptyEl = document.getElementById('cart-empty');

  function updateCart(updated) {
    cart = updated;
    saveCart(cart);
    window.zyphroa.renderNav(cart.length);
    render();
  }

  function render() {
    if (!cart.length) {
      container.innerHTML = '';
      container.style.display = 'none';
      emptyEl.style.display = 'block';
      return;
    }
    container.style.display = 'block';
    emptyEl.style.display = 'none';

    var total = 0;
    var html = cart
      .map(function (item, idx) {
        var subtotal = item.price * item.qty;
        total += subtotal;
        return (
          '<div class="cart-item" data-idx="' + idx + '">' +
          '<img class="cart-item-image" src="' + item.image + '" alt="" width="80" height="80" loading="lazy">' +
          '<div class="cart-item-name">' + item.title + '</div>' +
          '<div class="cart-item-price">' + formatPrice(item.price) + '</div>' +
          '<div class="cart-qty">' +
          '<button type="button" class="qty-minus" aria-label="Decrease quantity">−</button>' +
          '<span>' + item.qty + '</span>' +
          '<button type="button" class="qty-plus" aria-label="Increase quantity">+</button>' +
          '</div>' +
          '<div class="cart-item-subtotal">' + formatPrice(subtotal) + '</div>' +
          '<button type="button" class="cart-remove" aria-label="Remove item">Remove</button>' +
          '</div>'
        );
      })
      .join('');

    html +=
      '<div class="cart-summary">' +
      '<div class="cart-summary-row grand">' +
      '<span>Grand Total</span><span id="grand-total">' + formatPrice(total) + '</span>' +
      '</div>' +
      '<a href="checkout.html" class="btn btn-primary checkout-btn">Proceed to Checkout</a>' +
      '</div>';

    container.innerHTML = html;

    container.querySelectorAll('.qty-minus').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var idx = parseInt(this.closest('.cart-item').dataset.idx, 10);
        var item = cart[idx];
        if (item.qty <= 1) {
          cart.splice(idx, 1);
        } else {
          item.qty -= 1;
        }
        updateCart(cart);
      });
    });
    container.querySelectorAll('.qty-plus').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var idx = parseInt(this.closest('.cart-item').dataset.idx, 10);
        cart[idx].qty += 1;
        updateCart(cart);
      });
    });
    container.querySelectorAll('.cart-remove').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var idx = parseInt(this.closest('.cart-item').dataset.idx, 10);
        cart.splice(idx, 1);
        updateCart(cart);
      });
    });
  }

  render();
})();
