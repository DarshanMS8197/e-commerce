(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;

  var cart = getCart();
  window.zyphroa.renderNav(cart.length);

  if (!cart.length) {
    window.location.href = 'cart.html';
    return;
  }

  var params = new URLSearchParams(window.location.search);
  var total = cart.reduce(function (sum, item) { return sum + item.price * item.qty; }, 0);

  var totalEl = document.getElementById('payment-total');
  if (totalEl) {
    totalEl.innerHTML =
      '<div class="cart-summary-row grand">' +
      '<span>Amount to Pay</span><span>' + formatPrice(total) + '</span>' +
      '</div>';
  }

  function formatCardNumber(val) {
    var v = val.replace(/\s/g, '').replace(/\D/g, '');
    var parts = [];
    for (var i = 0; i < v.length && i < 16; i += 4) {
      parts.push(v.slice(i, i + 4));
    }
    return parts.join(' ');
  }

  function formatExpiry(val) {
    var v = val.replace(/\D/g, '');
    if (v.length >= 2) {
      return v.slice(0, 2) + '/' + v.slice(2, 4);
    }
    return v;
  }

  var cardNumber = document.getElementById('card-number');
  var cardExpiry = document.getElementById('card-expiry');
  if (cardNumber) {
    cardNumber.addEventListener('input', function () {
      this.value = formatCardNumber(this.value);
    });
  }
  if (cardExpiry) {
    cardExpiry.addEventListener('input', function () {
      this.value = formatExpiry(this.value);
    });
  }

  var form = document.getElementById('payment-form');
  var formSuccess = document.getElementById('payment-success');
  var errEl = document.getElementById('payment-error');

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (errEl) errEl.textContent = '';

    var cardNum = (document.getElementById('card-number').value || '').replace(/\s/g, '');
    var expiry = document.getElementById('card-expiry').value;
    var cvv = document.getElementById('card-cvv').value;

    if (cardNum.length < 13) {
      if (errEl) errEl.textContent = 'Enter a valid card number';
      return;
    }
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      if (errEl) errEl.textContent = 'Enter expiry as MM/YY';
      return;
    }
    if (!cvv || cvv.length < 3) {
      if (errEl) errEl.textContent = 'Enter a valid CVV';
      return;
    }

    var orderId = generateOrderId();
    var orderCart = getCart();
    var orderTotal = orderCart.reduce(function (s, i) { return s + i.price * i.qty; }, 0);
    var order = {
      id: orderId,
      date: new Date().toISOString(),
      items: orderCart.map(function (i) {
        return { title: i.title, qty: i.qty, price: i.price };
      }),
      total: orderTotal
    };
    saveOrder(order);
    saveCart([]);
    window.zyphroa.renderNav(0);

    form.style.display = 'none';
    if (formSuccess) formSuccess.style.display = 'block';
  });
})();
