/* Zyphroa - Data & Storage */
const STORAGE_KEYS = {
  USERS: 'zyphroa_users',
  CURRENT_USER: 'zyphroa_current_user',
  CART: 'zyphroa_cart',
  ORDERS: 'zyphroa_orders'
};
const PRODUCTS = [
  { id: '1', title: 'Smart LED TV 43 inch', price: 32999, rating: 4.5, genre: 'Electronics', image: 'https://images.samsung.com/is/image/samsung/p6pim/in/ua43ue84afulxl/energylabel/in-energylabel-product-ua43ue84afulxl-550349017?$Q90_1920_1280_F_PNG$', description: 'Full HD Smart LED TV with built-in streaming apps and multiple HDMI ports.' },
  { id: '2', title: 'Wireless Bluetooth Earphones', price: 1499, rating: 4.3, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1598331668826-20cecc596b86?w=400', description: 'Premium sound quality with 20hr battery life. IPX5 water resistant.' },
  { id: '3', title: 'Microwave Oven 20L', price: 5499, rating: 4.4, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1585659722983-3a675dabf23d?w=400', description: 'Compact microwave with multiple power levels and auto-cook menus.' },
  { id: '4', title: 'Electric Kettle 1.5L', price: 899, rating: 4.6, genre: 'Home Appliances', image: 'https://m.media-amazon.com/images/I/319Xp6ptC4L._SX300_SY300_QL70_FMwebp_.jpg', description: 'Fast boiling with auto shut-off and stainless steel body.' },
  { id: '5', title: 'Laptop Stand Aluminum', price: 1299, rating: 4.2, genre: 'Accessories', image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTjgfp8Qid9_s17tN-sLVwGYYJsOPTfj5NLYYKzszoLYPSD8uAH-XRxwlmXkvT7aKthj0fgvfnWFLin2KRC_xakS75kVWFIo9Yu2XZDWvNwmfkOik3d5G_yIUFyvlzu6aycSZD7hu_weBU&usqp=CAc' },
  { id: '6', title: 'Smartphone 128GB', price: 24999, rating: 4.5, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400', description: '6.5" AMOLED display, triple camera, 5000mAh battery.' },
  { id: '7', title: 'Air Fryer 4.2L', price: 4499, rating: 4.4, genre: 'Home Appliances', image: 'https://www.solara.in/cdn/shop/files/AFO_002_1.jpg?v=1769774691&width=1080', description: 'Oil-free cooking with digital touch control. 8 presets.' },
  { id: '8', title: 'USB-C Hub 7-in-1', price: 1899, rating: 4.1, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400', description: 'HDMI, USB 3.0, SD card reader, PD charging.' },
  { id: '9', title: 'Bluetooth Speaker', price: 1999, rating: 4.3, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400', description: '360° sound, 12hr playback. IPX7 waterproof.' },
  { id: '10', title: 'Iron with Steam', price: 1299, rating: 4.0, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400', description: 'Non-stick soleplate, variable steam. Anti-drip system.' },
  { id: '11', title: 'Power Bank 20000mAh', price: 1499, rating: 4.4, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400', description: 'Dual USB output, fast charging. LED indicator.' },
  { id: '12', title: 'Wireless Mouse', price: 599, rating: 4.2, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400', description: 'Ergonomic design, 2.4GHz wireless. 18 months battery life.' },
  { id: '13', title: 'Mixer Grinder 750W', price: 3299, rating: 4.5, genre: 'Home Appliances', image: 'https://m.media-amazon.com/images/I/71pdjDZ9ADL._SL1500_.jpg', description: '3 stainless steel jars. Multi-function grinding.' },
  { id: '14', title: 'Table Lamp LED', price: 799, rating: 4.0, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400', description: 'Touch dimmable, 3 brightness levels. Modern design.' },
  { id: '15', title: 'Mechanical Keyboard', price: 3999, rating: 4.6, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400', description: 'RGB backlight, Cherry MX style switches. Durable build.' },
  { id: '16', title: 'Smart Watch', price: 2999, rating: 4.3, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', description: 'Heart rate, SpO2, sleep tracking. 10+ sports modes.' },
  { id: '17', title: 'Trimmer for Men', price: 999, rating: 4.2, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=400', description: 'Cordless with 60min runtime. Washable blades.' },
  { id: '18', title: 'Phone Holder Car', price: 399, rating: 4.1, genre: 'Accessories', image: 'https://m.media-amazon.com/images/I/31FAzGR-l8L._SY300_SX300_QL70_FMwebp_.jpg', description: 'Dashboard mount, 360° rotation. Strong grip.' },
  { id: '19', title: 'Gaming Headset 7.1', price: 2499, rating: 4.5, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400', description: 'Surround sound with noise-canceling mic.' },
  { id: '20', title: 'External SSD 1TB', price: 7499, rating: 4.8, genre: 'Accessories', image: 'https://m.media-amazon.com/images/I/41-T4nAAufL._SY300_SX300_QL70_FMwebp_.jpg', description: 'High-speed data transfer in a compact form factor.' },
  { id: '21', title: 'Coffee Maker 600ml', price: 1899, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=400', description: 'Drip coffee machine with permanent filter.' },
  { id: '22', title: 'Yoga Mat 6mm', price: 699, rating: 4.4, genre: 'Fitness', image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400', description: 'Anti-slip texture, eco-friendly material.' },
  { id: '23', title: 'Dumbbells Set 5kg', price: 1599, rating: 4.5, genre: 'Fitness', image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400', description: 'PVC coated weight set for home workouts.' },
  { id: '24', title: 'Resistance Bands', price: 499, rating: 4.1, genre: 'Fitness', image: 'https://m.media-amazon.com/images/I/81XVOdgBweS._SL1500_.jpg', description: 'Set of 5 levels for strength training.' },
  { id: '25', title: 'Office Chair Mesh', price: 6999, rating: 4.3, genre: 'Office', image: 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=400', description: 'Ergonomic mesh back with lumbar support.' },
  { id: '26', title: 'Webcam 1080p', price: 2199, rating: 4.2, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?w=400', description: 'Auto-focus and dual microphones for meetings.' },
  { id: '27', title: 'E-Reader 6 inch', price: 9999, rating: 4.7, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400', description: 'Paper-white display, weeks of battery life.' },
  { id: '28', title: 'Backpack 30L', price: 1499, rating: 4.4, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400', description: 'Water-resistant fabric with laptop sleeve.' },
  { id: '29', title: 'Hand Blender 300W', price: 1199, rating: 4.3, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1591130901921-3f0652bb3915?w=400', description: 'Stainless steel blades for smoothies and soups.' },
  { id: '30', title: 'Monitor 24 inch', price: 8999, rating: 4.5, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400', description: 'FHD IPS display with ultra-slim bezels.' },
  { id: '31', title: 'Gaming Mouse Pad', price: 499, rating: 4.6, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=400', description: 'Extended size for mouse and keyboard.' },
  { id: '32', title: 'DSLR Camera', price: 45999, rating: 4.8, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400', description: '24.1 MP sensor, 4K video recording.' },
  { id: '33', title: 'Toaster 2 Slice', price: 1299, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1584905066893-7d5c142ba4e1?w=400', description: 'Variable browning control with cancel button.' },
  { id: '34', title: 'Desk Organizer', price: 599, rating: 4.0, genre: 'Office', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b?w=400', description: 'Metal mesh with multiple compartments.' },
  { id: '35', title: 'Soundbar 120W', price: 6499, rating: 4.4, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=400', description: 'Wireless subwoofer and cinematic sound.' },
  { id: '36', title: 'HDMI Cable 1.5m', price: 299, rating: 4.5, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1585232004423-244e0e6904e3?w=400', description: 'High-speed 4K support gold plated.' },
  { id: '37', title: 'Digital Kitchen Scale', price: 699, rating: 4.3, genre: 'Home Appliances', image: 'https://thehomebasic.com/wp-content/uploads/2025/03/HB-KS200-GRN_Slide-4.jpg', description: 'Precise measurements up to 5kg.' },
  { id: '38', title: 'Running Shoes', price: 2499, rating: 4.5, genre: 'Fitness', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', description: 'Lightweight and breathable for daily runs.' },
  { id: '39', title: 'Water Bottle 1L', price: 399, rating: 4.4, genre: 'Fitness', image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSLKCdSkn0iFZgLHV6L5kUysc7RJbVTsSBiwMoMe-pHvtuxmHOF7tfQUocFcKOSLD6DaTdfTEBOsZqOV5GwlWK-OnFDt-g6M5Uwzvrddboo7PPJYOo7GhfWVIz1mZ3XMLluB9pZBfQ&usqp=CAc', description: 'BPA-free durable plastic bottle.' },
  { id: '40', title: 'Electric Toothbrush', price: 1499, rating: 4.6, genre: 'Electronics', image: 'https://m.media-amazon.com/images/I/31wpQFByClL._SY300_SX300_QL70_FMwebp_.jpg', description: 'Sonic vibrations for superior cleaning.' },
  { id: '41', title: 'Rice Cooker 1.8L', price: 2199, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=400', description: 'Automatic keep warm function.' },
  { id: '42', title: 'Bluetooth Mouse', price: 899, rating: 4.1, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=400', description: 'Silent click, multi-device connection.' },
  { id: '43', title: 'Projector 1080p', price: 12999, rating: 4.3, genre: 'Electronics', image: 'https://wzatco.com/wp-content/uploads/2025/08/YUVA-GO-1.webp', description: 'Home theater projector with WiFi support.' },
  { id: '44', title: 'Floor Lamp', price: 2499, rating: 4.4, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400', description: 'Elegant design for modern living rooms.' },
  { id: '45', title: 'Fitness Tracker', price: 1999, rating: 4.2, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400', description: 'Step counter, calorie tracker, slim design.' },
  { id: '46', title: 'Paper Shredder', price: 3499, rating: 4.0, genre: 'Office', image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400', description: 'Cross-cut shredder for home office.' },
  { id: '47', title: 'Mini Fridge 45L', price: 8999, rating: 4.5, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400', description: 'Low noise, compact cooling.' },
  { id: '48', title: 'Action Camera 4K', price: 5999, rating: 4.3, genre: 'Electronics', image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRAQ4Aj-xA3VHvLV9b22Bmro94eKcLO6sghauMIPrP4Ez358QrT26nFiiAOXve3KJ7o-tuOOH0CkMet_3XMqXdK18L3QgFh9LrBulqVdB0ToD6engen_xwmFEuEsxSLTO3vkapHKOL0TEM&usqp=CAc', description: 'Waterproof casing, wide angle lens.' },
  { id: '49', title: 'Portable Hard Drive 2TB', price: 5499, rating: 4.7, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400', description: 'Large storage for backups.' },
  { id: '50', title: 'Coffee Grinder', price: 1499, rating: 4.1, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400', description: 'Electric grinder for fresh beans.' },
  { id: '51', title: 'Graphics Tablet', price: 4999, rating: 4.5, genre: 'Electronics', image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcS302o8H8gI2Sfc4JpmfqkW7kTrCmfKCod4mdYVqdPLltHyRf5aJ2-hyaNldhTevJkKNkUXkJ_T47J36NDfF_vEYqtvDkCge3iTG_BWZiYEMEG2HKV8XRzcD-zQkhTKnWCJT8v9VpdOwQ&usqp=CAc', description: 'Battery-free stylus for digital art.' },
  { id: '52', title: 'Hair Dryer 1200W', price: 899, rating: 4.3, genre: 'Electronics', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSr-WPyvYJNOjefGlpPYoVi55hjYjCc06q-2C5tUOH9o5CbhvrV7MzPlk7hCt2GoB_XnGps0hHVH78A67AbpRoh1BIQD3yzdMzBjH8CzEBATIle78diNp8ALw', description: 'Two heat settings, foldable handle.' },
  { id: '53', title: 'Wall Clock', price: 499, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=400', description: 'Silent sweep non-ticking design.' },
  { id: '54', title: 'Electric Grill', price: 2999, rating: 4.4, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1550989460-0adf9ea622e2?w=400', description: 'Non-stick surface for indoor grilling.' },
  { id: '55', title: 'Memory Card 64GB', price: 699, rating: 4.6, genre: 'Accessories', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRroaWHC5hF6fUXqJkShtX7xsQZmW1bdtS1iAFT-woNh17s4zxLfQzhwfA9HgcSveMap2kHnFhsP6Sp087tX82OOdJFsBF0H41aVsyReY3W76YXkva93XxpLg', description: 'Class 10 UHS-I for fast recording.' },
  { id: '56', title: 'Calculator Scientific', price: 1299, rating: 4.5, genre: 'Office', image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTNfDnlyr14DssYMxbR8o595N5pqUmtPtCQ3vlilLgVNWPnocJmaXj5AdIg7-gLNhGE85iaW18P5tVvnrmmUrVZTL0K5-ubP7flKvkenU8VRemGAJV5vbe7e7QyOWqXASkjjvJkRmc&usqp=CAc', description: 'Advanced mathematical functions.' },
  { id: '57', title: 'LED Strip Lights', price: 599, rating: 4.3, genre: 'Home Appliances', image: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSQ565_7YC4-Z9mnl-trqVHDQblHV3021Lj3gAoGRDfMKZ6-XjsY-wzu_4PXP2gQJPlxwGhcQYfGaN9Ov6dL560-gHqyyYt', description: 'RGB color changing with remote.' },
  { id: '58', title: 'Smart Bulb', price: 799, rating: 4.4, genre: 'Electronics', image: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQkzL26Hto5x9PaaxLTHG0uXQ-xafE4bqeiMEZRdAKrXf0V83APENLgHYxM5T96tBM0tvEVhp8H1ige1CDUfKDyvZNxtUxF', description: 'App controlled, millions of colors.' },
  { id: '59', title: 'Wireless Charger', price: 1299, rating: 4.2, genre: 'Accessories', image: 'https://m.media-amazon.com/images/I/31C12XtLqgL._SY300_SX300_QL70_FMwebp_.jpg', description: 'Fast Qi-charging for compatible phones.' },
  { id: '60', title: 'CCTV Camera', price: 2499, rating: 4.4, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=400', description: '360° view with night vision.' },
  { id: '61', title: 'Punching Bag', price: 3499, rating: 4.3, genre: 'Fitness', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcS55GODY-mZ2PAO4-MCtjvSA3juMjnTypkYeUcJLbT4K1UKkdOhHnyGp1fcXiHPsRUmpl7zxQUf16P3XNjnCUQ2ttEufhvE3pKQ1k9JViVyx3si3mUq6plt7A', description: 'Heavy duty bag for martial arts.' },
  { id: '62', title: 'Binoculars 10x50', price: 1899, rating: 4.1, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1511910849309-0dffb8785146?w=400', description: 'Clear vision for bird watching.' },
  { id: '63', title: 'Induction Cooktop', price: 2699, rating: 4.5, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400', description: 'Fast heating, preset Indian menus.' },
  { id: '64', title: 'Whiteboard 3x2ft', price: 1299, rating: 4.4, genre: 'Office', image: 'https://m.media-amazon.com/images/I/71vKDFn7raL._SX679_.jpg', description: 'Magnetic surface with aluminum frame.' },
  { id: '65', title: 'Thermal Flask 500ml', price: 799, rating: 4.3, genre: 'Accessories', image: 'https://rukminim2.flixcart.com/image/1280/1280/xif0q/bottle/n/i/q/500-flip-lid-500-thermosteel-water-bottle-isi-certified-24-hr-original-imahgwq9j4d3adzu.jpeg?q=90', description: 'Keeps beverages hot or cold for 12hrs.' },
  { id: '66', title: 'WiFi Router 300Mbps', price: 1199, rating: 4.2, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=400', description: 'High-speed internet for home usage.' },
  { id: '67', title: 'Curtain Rods', price: 499, rating: 4.0, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=400', description: 'Extendable metal rods.' },
  { id: '68', title: 'Yoga Block', price: 349, rating: 4.5, genre: 'Fitness', image: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=400', description: 'High density foam for support.' },
  { id: '69', title: 'Measuring Tape 5m', price: 299, rating: 4.4, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1586769852836-bc069f19e1b6?w=400', description: 'Durable steel tape with lock.' },
  { id: '70', title: 'Table Fan 400mm', price: 1899, rating: 4.2, genre: 'Home Appliances', image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTuAkglxmxyeZsUnbE3HHZBNZYN3o-gfINXRhVPDR22ToKy015qjf4cZ02M3InppqFjC6WqS7Ch5VVLN92ZPFQnXITwWTLGOw-PYs2Sk-L80ae_S5jxiCgUuOQ', description: 'High speed oscillation.' },
  { id: '71', title: 'Selfie Stick Tripod', price: 899, rating: 4.3, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1533038590840-1cde6e668a91?w=400', description: 'Bluetooth remote for vlogging.' },
  { id: '72', title: 'Lunch Box 3 Tiers', price: 699, rating: 4.1, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1584346133934-a3afd2a33c4c?w=400', description: 'Insulated stainless steel containers.' },
  { id: '73', title: 'Extension Cord 4-Way', price: 549, rating: 4.5, genre: 'Accessories', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTYS44CKOlq7ioR1SdN3bi1wLudksJhiO4_rU6QoxYz_cCa67dQbCiTdPOzT-cNUdG9Ca5hJaY1iUMGR8DXPK1Hlo6y368jFid4OvNnd6A7tLjkxdvekue3Ew', description: 'Surge protector with long cable.' },
  { id: '74', title: 'Drip Irrigation Kit', price: 1299, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=400', description: 'DIY garden watering system.' },
  { id: '75', title: 'Laptop Sleeve 14 inch', price: 499, rating: 4.6, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=400', description: 'Soft padding for laptop protection.' },
  { id: '76', title: 'Pencil Case', price: 199, rating: 4.3, genre: 'Office', image: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=400', description: 'Large capacity stationery pouch.' },
  { id: '77', title: 'Magnifying Glass', price: 249, rating: 4.0, genre: 'Accessories', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQ7HzwtJIrORnddUUe1eoT_76ogfEOuAFAyOg-dW5Ycs_qt86-l7E9bqSSJUdUWTDW86ccP3wuVLBIzkH6sdvdkgcrsszg16qcIzFEaVNQ-aGXRkLAqipUUJg', description: '5x magnification with LED light.' },
  { id: '78', title: 'Bluetooth Aux Adapter', price: 399, rating: 4.2, genre: 'Electronics', image: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQ-h8Loo98aGvgBNV8yG67vEBy6y8sRsfLjz0xmRQwevMMAMktjkVxZldZyPekH_XJsNVPovT6lQ249YzEjvWJy-paeWoz8_qYL13IeOr0', description: 'Convert car stereo to wireless.' },
  { id: '79', title: 'Digital Alarm Clock', price: 599, rating: 4.3, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?w=400', description: 'Large LED display with temperature.' },
  { id: '80', title: 'Notebook A5', price: 299, rating: 4.7, genre: 'Office', image: 'https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=400', description: 'Hardcover ruled pages.' },
  { id: '81', title: 'Rechargeable Fan', price: 1299, rating: 4.1, genre: 'Electronics', image: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTP1ecJmFvcUZAv4A9WBiQR-GFFfWIf5gcAcmCDOmCOWIiBY_7qnXb5RSSrQ8MnUvIkOk4KdFe1cLtcUYkpAXUPFjZikXFrKr2lKF0iUg0NkgRX-s2ccvy4Sw', description: 'Portable fan for power cuts.' },
  { id: '82', title: 'Vacuum Flask', price: 999, rating: 4.4, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1517331156700-3c241d2b4d83?w=400', description: 'Double wall insulation.' },
  { id: '83', title: 'Skipping Rope', price: 249, rating: 4.5, genre: 'Fitness', image: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=400', description: 'Adjustable length for cardio.' },
  { id: '84', title: 'HDMI Splitter', price: 799, rating: 4.0, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400', description: '1 In 2 Out dual monitor support.' },
  { id: '85', title: 'Webcam Cover', price: 149, rating: 4.8, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1593642532400-2682810df593?w=400', description: 'Slide cover for privacy.' },
  { id: '86', title: 'Sandwich Maker', price: 1599, rating: 4.3, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1584905066893-7d5c142ba4e1?w=400', description: 'Non-stick grill plates.' },
  { id: '87', title: 'Tool Kit 30pcs', price: 1999, rating: 4.6, genre: 'Accessories', image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQKrTThYO6dkCo6LT5txrJ76rBxDPrAtOGAF3dDRJwXTVZ2A5I_F5jyvHkgZbAI6dekXa_Cv7e8W6lVjI5hQclsjJrzZMra8Q', description: 'Complete home repair set.' },
  { id: '88', title: 'Flashlight LED', price: 499, rating: 4.2, genre: 'Accessories', image: 'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRbmAAgFeXhvQKSAlsjucMAU25AeehAQG86uPVPBsX9T62QV4IoVwCHn78Wv3er3i-HgLG2rQw7pd4isalld5e9RjnVHd8-9yM1ttfuKko5XC3tuPydAObj', description: 'Zoomable high-beam light.' },
  { id: '89', title: 'USB Wall Charger', price: 699, rating: 4.4, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400', description: 'Dual port 2.4A output.' },
  { id: '90', title: 'Hand Sanitizer 5L', price: 899, rating: 4.5, genre: 'Home Appliances', image: 'https://m.media-amazon.com/images/I/710t27PapBL._SL1500_.jpg', description: '70% Alcohol based bulk pack.' },
  { id: '91', title: 'Electric Kettle 1L', price: 749, rating: 4.3, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1594179047519-f347310d3322?w=400', description: 'Small capacity for travel.' },
  { id: '92', title: 'Mouse Bungee', price: 599, rating: 4.0, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400', description: 'Cable management for gamers.' },
  { id: '93', title: 'Reading Light', price: 349, rating: 4.4, genre: 'Electronics', image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400', description: 'Clip-on light for books.' },
  { id: '94', title: 'Passport Holder', price: 499, rating: 4.5, genre: 'Accessories', image: 'https://images.unsplash.com/photo-1544256718-3bcf237f3974?w=400', description: 'Leather wallet for travel docs.' },
  { id: '95', title: 'Stapler Heavy Duty', price: 399, rating: 4.2, genre: 'Office', image: 'https://images.unsplash.com/photo-1590247813693-5541d1c609fd?w=400', description: 'Staples up to 50 sheets.' },
  { id: '96', title: 'Cooling Pad Laptop', price: 1299, rating: 4.1, genre: 'Accessories', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSh8t3Mta0aSSO3L4wvz6S-bqgZE2HbgxGVt3740d5s9KPyHLHpUVeUVY6XqWM3YSPRKcfPVvIysLX5tby7CwZUWQsnD0qpWKpioT3CuFlhvPWn3QXMyuOHkwo', description: 'Dual fan cooling system.' },
  { id: '97', title: 'Wall Mount TV', price: 999, rating: 4.6, genre: 'Accessories', image: 'https://rukminim2.flixcart.com/image/480/640/xif0q/tv-mount/c/g/m/14-lcd-led-plasma-tv-swivel-type-movable-wall-mount-bracket-original-imahe3desywe4sjf.jpeg?q=90', description: 'Sturdy bracket for 32-55 inch.' },
  { id: '98', title: 'Bluetooth Keyboard', price: 1499, rating: 4.3, genre: 'Accessories', image: 'https://m.media-amazon.com/images/I/61U7MWJP9rL.jpg', description: 'Ultra-slim for tablets and phones.' },
  { id: '99', title: 'Wireless Doorbell', price: 899, rating: 4.2, genre: 'Home Appliances', image: 'https://images.unsplash.com/photo-1558002038-1055907df827?w=400', description: '300m range with multiple tunes.' },
  { id: '100', title: 'Car Vacuum Cleaner', price: 1899, rating: 4.4, genre: 'Accessories', image: 'https://m.media-amazon.com/images/I/41Q-lfcHgNL._SY300_SX300_QL70_FMwebp_.jpg', description: 'Portable handheld for interiors.' }
];

function getUsers() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveUser(email, password) {
  const users = getUsers();
  if (users[email]) return false;
  users[email] = { email, password };
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  return true;
}

function validateLogin(email, password) {
  const users = getUsers();
  const user = users[email];
  return user && user.password === password;
}

function setCurrentUser(email) {
  if (email) localStorage.setItem(STORAGE_KEYS.CURRENT_USER, email);
  else localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
}

function getCurrentUser() {
  return localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
}

function getCart() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CART);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
}

function getOrders() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveOrder(order) {
  const orders = getOrders();
  orders.unshift(order);
  localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
}

function getProductById(id) {
  return PRODUCTS.find(p => p.id === id) || null;
}

function formatPrice(price) {
  return '₹' + Number(price).toLocaleString('en-IN');
}

function generateOrderId() {
  return 'ZY' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
}
