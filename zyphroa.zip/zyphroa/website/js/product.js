(function () {
  if (!window.zyphroa || !window.zyphroa.guard()) return;
  window.zyphroa.renderNav();

  var params = new URLSearchParams(window.location.search);
  var id = params.get('id');
  var product = id ? getProductById(id) : null;
  var detailEl = document.getElementById('product-detail');
  var notFoundEl = document.getElementById('product-not-found');

  function showToast(msg) {
    var toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(function () {
      toast.classList.remove('show');
    }, 2500);
  }

  function addToCart() {
    if (!product) return;
    var cart = getCart();
    var i = cart.findIndex(function (x) { return x.id === product.id; });
    if (i >= 0) cart[i].qty += 1;
    else cart.push({ id: product.id, title: product.title, price: product.price, image: product.image, qty: 1 });
    saveCart(cart);
    window.zyphroa.renderNav(cart.length);
    showToast('Added to cart');
  }

  if (!product) {
    detailEl.style.display = 'none';
    notFoundEl.style.display = 'block';
    return;
  }

  detailEl.style.display = 'grid';
  detailEl.innerHTML =
    '<div class="product-detail-image">' +
    '<img src="' + product.image + '" alt="' + product.title.replace(/"/g, '&quot;') + '" width="500" height="500" loading="eager">' +
    '</div>' +
    '<div class="product-detail-info">' +
    '<h1>' + product.title + '</h1>' +
    '<p class="product-detail-price">' + formatPrice(product.price) + '</p>' +
    '<p class="product-detail-meta">Genre: ' + (product.genre || '—') + ' &nbsp;|&nbsp; ★ ' + product.rating + '</p>' +
    '<p class="product-detail-desc">' + (product.description || '') + '</p>' +
    '<button type="button" class="btn btn-primary" id="add-to-cart">Add to Cart</button>' +
    '</div>';

  document.getElementById('add-to-cart').addEventListener('click', addToCart);
})();
