const express = require('express');
const Order = require('../models/Order');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

const router = express.Router();

// All order routes require authentication
router.use(protect);

/**
 * @route   POST /api/orders
 * @desc    Create new order
 */
router.post('/', [
  body('products').isArray({ min: 1 }).withMessage('At least one product required'),
  body('address.fullName').trim().notEmpty().withMessage('Full name is required'),
  body('address.street').trim().notEmpty().withMessage('Street address is required'),
  body('address.city').trim().notEmpty().withMessage('City is required'),
  body('address.state').trim().notEmpty().withMessage('State is required'),
  body('address.zipCode').trim().notEmpty().withMessage('ZIP code is required'),
  body('address.phone').trim().notEmpty().withMessage('Phone is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { products: cartProducts, address, paymentMethod = 'Credit Card' } = req.body;

    // Validate products and get current prices
    const orderProducts = [];
    let totalPrice = 0;

    for (const item of cartProducts) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return res.status(404).json({
          success: false,
          message: `Product ${item.productId} not found`
        });
      }
      if (product.stock < (item.quantity || 1)) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${product.name}`
        });
      }

      const quantity = Math.min(item.quantity || 1, product.stock);
      const subtotal = product.price * quantity;
      totalPrice += subtotal;

      orderProducts.push({
        productId: product._id,
        name: product.name,
        price: product.price,
        quantity,
        image: product.image
      });

      // Reduce stock
      product.stock -= quantity;
      await product.save();
    }

    const order = await Order.create({
      userId: req.user._id,
      products: orderProducts,
      totalPrice,
      address,
      paymentMethod,
      trackingHistory: [{
        stage: 'Order Placed',
        message: 'Your order has been placed successfully.'
      }]
    });

    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      data: order
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   GET /api/orders
 * @desc    Get user's order history
 */
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .lean();

    res.json({
      success: true,
      data: orders
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   GET /api/orders/:orderId
 * @desc    Get single order and track
 */
router.get('/:orderId', async (req, res) => {
  try {
    const order = await Order.findOne({
      orderId: req.params.orderId,
      userId: req.user._id
    }).lean();

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   PATCH /api/orders/:orderId/status
 * @desc    Update order status (admin - for testing/demo)
 */
router.patch('/:orderId/status', async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status'
      });
    }

    const order = await Order.findOne({
      orderId: req.params.orderId,
      userId: req.user._id
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    order.status = status;
    order.trackingHistory.push({
      stage: status,
      message: `Order status updated to ${status}`
    });

    if (status === 'Shipped' && !order.shippingDate) {
      order.shippingDate = new Date();
    }
    if (status === 'Delivered' && !order.deliveryDate) {
      order.deliveryDate = new Date();
    }

    await order.save();

    res.json({
      success: true,
      data: order
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

module.exports = router;
