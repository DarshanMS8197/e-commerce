const express = require('express');
const Product = require('../models/Product');

const router = express.Router();

/**
 * @route   GET /api/products
 * @desc    Get all products with filters and pagination
 */
router.get('/', async (req, res) => {
  try {
    const { category, search, sort, page = 1, limit = 24 } = req.query;
    const query = {};

    // Category filter
    if (category && category !== 'all') {
      query.category = new RegExp(category, 'i');
    }

    // Search filter
    if (search && search.trim()) {
      query.$or = [
        { name: new RegExp(search.trim(), 'i') },
        { description: new RegExp(search.trim(), 'i') },
        { category: new RegExp(search.trim(), 'i') }
      ];
    }

    let sortOption = { createdAt: -1 };
    if (sort === 'price-asc') sortOption = { price: 1 };
    if (sort === 'price-desc') sortOption = { price: -1 };
    if (sort === 'rating') sortOption = { rating: -1 };
    if (sort === 'name') sortOption = { name: 1 };

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const products = await Product.find(query)
      .sort(sortOption)
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    const total = await Product.countDocuments(query);

    res.json({
      success: true,
      data: products,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   GET /api/products/search/suggestions
 * @desc    Get search suggestions (autocomplete)
 */
router.get('/search/suggestions', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.json({ success: true, data: [] });
    }

    const products = await Product.find({
      $or: [
        { name: new RegExp(q.trim(), 'i') },
        { category: new RegExp(q.trim(), 'i') }
      ]
    })
      .select('name category image price')
      .limit(8)
      .lean();

    const categories = [...new Set(products.map(p => p.category))];
    res.json({
      success: true,
      data: products,
      categories
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   GET /api/products/categories
 * @desc    Get all unique categories
 */
router.get('/categories', async (req, res) => {
  try {
    const categories = await Product.distinct('category');
    res.json({
      success: true,
      data: categories.sort()
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

/**
 * @route   GET /api/products/:id
 * @desc    Get single product by ID
 */
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).lean();
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    res.json({
      success: true,
      data: product
    });
  } catch (err) {
    if (err.kind === 'ObjectId') {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    res.status(500).json({
      success: false,
      message: err.message || 'Server error'
    });
  }
});

module.exports = router;
