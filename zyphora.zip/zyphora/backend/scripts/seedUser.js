require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');

async function seedUser() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/zyphora');
    const exists = await User.findOne({ email: 'test@zyphora.com' });
    if (!exists) {
      await User.create({
        name: 'Test User',
        email: 'test@zyphora.com',
        password: 'password123'
      });
      console.log('Test user created: test@zyphora.com / password123');
    } else {
      console.log('Test user already exists');
    }
    process.exit(0);
  } catch (err) {
    console.error('Seed error:', err);
    process.exit(1);
  }
}

seedUser();
