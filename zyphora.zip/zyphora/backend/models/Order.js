const mongoose = require('mongoose');

const trackingHistorySchema = new mongoose.Schema({
  stage: {
    type: String,
    enum: ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'],
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  message: {
    type: String,
    default: ''
  }
});

const orderProductSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  name: String,
  price: Number,
  quantity: {
    type: Number,
    required: true,
    min: 1
  },
  image: String
});

const orderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true,
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  products: [orderProductSchema],
  totalPrice: {
    type: Number,
    required: true,
    min: 0
  },
  status: {
    type: String,
    enum: ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'],
    default: 'Order Placed'
  },
  orderDate: {
    type: Date,
    default: Date.now
  },
  shippingDate: {
    type: Date
  },
  deliveryDate: {
    type: Date
  },
  estimatedShippingDate: {
    type: Date
  },
  estimatedDeliveryDate: {
    type: Date
  },
  address: {
    fullName: { type: String, required: true },
    street: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    zipCode: { type: String, required: true },
    phone: { type: String, required: true }
  },
  paymentMethod: {
    type: String,
    default: 'Credit Card'
  },
  trackingHistory: [trackingHistorySchema],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Generate order ID before save
orderSchema.pre('save', async function(next) {
  if (!this.orderId) {
    this.orderId = 'ZYP-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6).toUpperCase();
  }
  if (this.trackingHistory.length === 0) {
    this.trackingHistory.push({
      stage: 'Order Placed',
      message: 'Your order has been placed successfully.'
    });
  }
  // Auto-calculate estimated dates
  if (!this.estimatedShippingDate) {
    const shipDate = new Date(this.orderDate);
    shipDate.setDate(shipDate.getDate() + Math.floor(Math.random() * 2) + 1); // 1-2 days
    this.estimatedShippingDate = shipDate;
  }
  if (!this.estimatedDeliveryDate) {
    const delDate = new Date(this.estimatedShippingDate || this.orderDate);
    delDate.setDate(delDate.getDate() + Math.floor(Math.random() * 5) + 3); // 3-7 days
    this.estimatedDeliveryDate = delDate;
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
