# Zyphora - E-commerce Marketplace

A complete, production-style e-commerce web application similar to Amazon, Flipkart, or Myntra. Built with modern web technologies, designed for Lighthouse scores 90-95.

## Tech Stack

- **Frontend:** HTML5, CSS3, JavaScript (ES6)
- **Backend:** Node.js, Express.js
- **Database:** MongoDB with Mongoose
- **Testing:** Playwright (E2E), Selenium (Java + TestNG), Jest (Unit), k6 (Performance)
- **Reports:** Allure for Playwright and Selenium

## Project Structure

```
zyphora/
├── backend/           # Express API
│   ├── models/        # User, Product, Order
│   ├── routes/        # auth, products, orders
│   ├── middleware/    # auth
│   └── scripts/       # seedProducts.js
├── frontend/          # Static HTML/CSS/JS
│   ├── css/
│   └── js/
├── tests/
│   ├── playwright/    # E2E tests
│   ├── selenium/      # Java Selenium tests
│   ├── jest/          # Unit tests
│   └── k6/            # Performance tests
└── README.md
```

## Prerequisites

- Node.js 18+
- MongoDB (local or Atlas)
- Java 11+ (for Selenium tests)
- Maven (for Selenium tests)
- k6 (for performance tests)

## Run Instructions

### 1. Install Dependencies

```bash
# Backend
cd zyphora/backend
npm install

# Frontend
cd zyphora/frontend
npm install

# Playwright tests
cd zyphora/tests/playwright
npm install
npx playwright install chromium

# Jest tests
cd zyphora/tests/jest
npm install
```

### 2. Start Backend

```bash
cd zyphora/backend
# Ensure MongoDB is running (e.g., mongod)
npm start
# Server runs on http://localhost:5000
```

### 3. Seed Database (200 products + test user)

```bash
cd zyphora/backend
npm run seed
```
Creates 200 products and test user: `test@zyphora.com` / `password123`

### 4. Start Frontend

```bash
cd zyphora/frontend
npm start
# Or: npx serve -s . -l 3000
# Frontend runs on http://localhost:3000
```

### 5. Run Playwright Tests

```bash
# Start backend + frontend first
cd zyphora/tests/playwright
npm test
```

### 6. Run Selenium Tests

```bash
# Start backend + frontend first
cd zyphora/tests/selenium
mvn clean test
```

### 7. Generate Allure Report

**Playwright:**
```bash
cd zyphora/tests/playwright
npm run report
# Opens Allure report in browser
```

**Selenium:**
```bash
cd zyphora/tests/selenium
mvn allure:serve
# Generates and opens Allure report
```

### 8. Run Performance Tests (k6)

```bash
# Install k6: https://k6.io/docs/getting-started/installation/
# Start backend first

cd zyphora/tests/k6
k6 run script.js
# Or for frontend homepage:
k6 run homepage.js
```

### 9. Run Jest Unit Tests

```bash
cd zyphora/tests/jest
# Cart tests (no backend needed):
npm test

# API tests (requires backend running):
npm test
```

## Core Features

- **User Auth:** Register, Login, Logout, Password validation, JWT session
- **Products:** 200 unique products, categories, search, filters
- **Cart:** Add/remove, quantity update, persistence, real-time total
- **Checkout:** Address form, payment simulation, order confirmation
- **Order Tracking:** 6-stage lifecycle (Placed → Confirmed → Packed → Shipped → Out for Delivery → Delivered)
- **My Orders:** Order history with Track Order button

## Test Coverage

- **Login:** Valid, invalid, empty fields, SQL injection
- **Register:** Valid, duplicate email, weak password
- **Search:** Valid, no results, case insensitive, special chars
- **Cart:** Add, remove, update quantity, persistence, total
- **Checkout:** Valid flow, empty cart, validation
- **Orders:** Creation, history, tracking, delivery estimate

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register user |
| POST | /api/auth/login | Login user |
| GET | /api/products | List products (filters, pagination) |
| GET | /api/products/search/suggestions | Search suggestions |
| GET | /api/products/categories | All categories |
| GET | /api/products/:id | Product detail |
| POST | /api/orders | Create order (auth) |
| GET | /api/orders | User orders (auth) |
| GET | /api/orders/:orderId | Track order (auth) |

## Environment Variables

Create `backend/.env`:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/zyphora
JWT_SECRET=your-secret-key
```

## Lighthouse Optimization

- Semantic HTML, alt text, heading structure
- Meta tags for SEO
- Lazy-loaded images
- Optimized fonts (Inter)
- Minimal layout shift (CLS)
- Fast load times

## License

MIT
