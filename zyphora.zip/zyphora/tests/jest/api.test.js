/**
 * Zyphora - API Unit Tests
 * Run with backend and MongoDB started
 */
const API_BASE = 'http://localhost:5000/api';

const fetchApi = async (endpoint, options = {}) => {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options
  });
  return res.json();
};

describe('Products API', () => {
  test('GET /products returns products', async () => {
    const data = await fetchApi('/products?limit=5');
    expect(data.success).toBe(true);
    expect(Array.isArray(data.data)).toBe(true);
  });

  test('GET /products with category filter', async () => {
    const data = await fetchApi('/products?category=Electronics&limit=5');
    expect(data.success).toBe(true);
    data.data.forEach(p => expect(p.category).toBe('Electronics'));
  });

  test('GET /products/categories returns categories', async () => {
    const data = await fetchApi('/products/categories');
    expect(data.success).toBe(true);
    expect(Array.isArray(data.data)).toBe(true);
  });

  test('GET /products/search/suggestions', async () => {
    const data = await fetchApi('/products/search/suggestions?q=phone');
    expect(data.success).toBe(true);
    expect(Array.isArray(data.data)).toBe(true);
  });

  test('GET /products/:id returns single product', async () => {
    const list = await fetchApi('/products?limit=1');
    if (list.data.length > 0) {
      const product = await fetchApi(`/products/${list.data[0]._id}`);
      expect(product.success).toBe(true);
      expect(product.data._id).toBe(list.data[0]._id);
    }
  });
});

describe('Auth API', () => {
  test('POST /auth/register - valid', async () => {
    const email = `jest${Date.now()}@test.com`;
    const data = await fetchApi('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name: 'Jest User', email, password: 'password123' })
    });
    expect(data.success).toBe(true);
    expect(data.token).toBeDefined();
    expect(data.user.email).toBe(email);
  });

  test('POST /auth/register - duplicate email', async () => {
    const data = await fetchApi('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name: 'Test', email: 'duplicate@zyphora.com', password: 'password123' })
    });
    expect(data.success).toBe(false);
  });

  test('POST /auth/login - invalid', async () => {
    const data = await fetchApi('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'invalid@test.com', password: 'wrong' })
    });
    expect(data.success).toBe(false);
  });
});
