/**
 * Zyphora - Cart Logic Unit Tests
 */
const storage = {};
const mockLocalStorage = {
  getItem: (k) => storage[k] || null,
  setItem: (k, v) => { storage[k] = v; },
  clear: () => { for (const k of Object.keys(storage)) delete storage[k]; }
};

const Cart = {
  getItems() {
    try {
      return JSON.parse(mockLocalStorage.getItem('zyphora_cart') || '[]');
    } catch {
      return [];
    }
  },
  setItems(items) {
    mockLocalStorage.setItem('zyphora_cart', JSON.stringify(items));
  },
  addItem(productId, quantity = 1, product = null) {
    const items = this.getItems();
    const existing = items.find(i => i.productId === productId);
    if (existing) {
      existing.quantity += quantity;
    } else {
      items.push({ productId, quantity, name: product?.name, price: product?.price, image: product?.image });
    }
    this.setItems(items);
  },
  removeItem(productId) {
    this.setItems(this.getItems().filter(i => i.productId !== productId));
  },
  updateQuantity(productId, quantity) {
    const items = this.getItems();
    const item = items.find(i => i.productId === productId);
    if (!item) return;
    if (quantity <= 0) {
      this.removeItem(productId);
      return;
    }
    item.quantity = quantity;
    this.setItems(items);
  },
  getTotal() {
    return this.getItems().reduce((sum, i) => sum + (i.price * i.quantity), 0);
  },
  getCount() {
    return this.getItems().reduce((sum, i) => sum + i.quantity, 0);
  },
  clear() {
    this.setItems([]);
  }
};

describe('Cart Logic', () => {
  beforeEach(() => {
    Cart.clear();
    mockLocalStorage.clear();
  });

  test('add item', () => {
    Cart.addItem('p1', 1, { name: 'Product', price: 10, image: '' });
    expect(Cart.getCount()).toBe(1);
    expect(Cart.getTotal()).toBe(10);
  });

  test('add same item increments quantity', () => {
    Cart.addItem('p1', 1, { price: 10 });
    Cart.addItem('p1', 2, { price: 10 });
    expect(Cart.getCount()).toBe(3);
    expect(Cart.getTotal()).toBe(30);
  });

  test('remove item', () => {
    Cart.addItem('p1', 1, { price: 10 });
    Cart.removeItem('p1');
    expect(Cart.getCount()).toBe(0);
    expect(Cart.getTotal()).toBe(0);
  });

  test('update quantity', () => {
    Cart.addItem('p1', 1, { price: 10 });
    Cart.updateQuantity('p1', 5);
    expect(Cart.getCount()).toBe(5);
    expect(Cart.getTotal()).toBe(50);
  });

  test('update quantity to zero removes item', () => {
    Cart.addItem('p1', 1, { price: 10 });
    Cart.updateQuantity('p1', 0);
    expect(Cart.getCount()).toBe(0);
  });

  test('cart persistence', () => {
    Cart.addItem('p1', 2, { price: 15 });
    const items = Cart.getItems();
    expect(items.length).toBe(1);
    expect(items[0].productId).toBe('p1');
    expect(items[0].quantity).toBe(2);
  });

  test('total calculation with multiple items', () => {
    Cart.addItem('p1', 2, { price: 10 });
    Cart.addItem('p2', 3, { price: 5 });
    expect(Cart.getTotal()).toBe(35);
  });
});
