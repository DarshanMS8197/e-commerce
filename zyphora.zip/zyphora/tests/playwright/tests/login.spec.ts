import { test, expect } from '@playwright/test';

test.describe('Login', () => {
  test('valid login', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'test@zyphora.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
  });

  test('invalid login - wrong password', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'test@zyphora.com');
    await page.fill('#password', 'wrongpassword');
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error')).toContainText(/invalid|failed/i);
  });

  test('invalid login - wrong email', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'nonexistent@test.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error')).toContainText(/invalid|failed/i);
  });

  test('empty email field', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#email-error')).toContainText(/required/i);
  });

  test('empty password field', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'test@zyphora.com');
    await page.click('button[type="submit"]');
    await expect(page.locator('#password-error')).toContainText(/required/i);
  });

  test('empty fields', async ({ page }) => {
    await page.goto('/login.html');
    await page.click('button[type="submit"]');
    await expect(page.locator('#email-error, #password-error')).toHaveCount(1);
  });

  test('SQL injection attempt', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', "admin'--");
    await page.fill('#password', "password' OR '1'='1");
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error')).toBeVisible();
  });

  test('login redirects to home when authenticated', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'AuthTest User');
    await page.fill('#email', `authtest${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
    await page.goto('/login.html');
    await expect(page).toHaveURL(/index\.html/);
  });
});
