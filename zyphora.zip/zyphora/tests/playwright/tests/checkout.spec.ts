import { test, expect } from '@playwright/test';

test.describe('Checkout', () => {
  test('checkout requires login', async ({ page }) => {
    await page.goto('/checkout.html');
    await expect(page.locator('text=login')).toBeVisible();
  });

  test('empty cart checkout', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Checkout Test');
    await page.fill('#email', `checkout${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
    await page.goto('/checkout.html');
    await expect(page.locator('text=empty')).toBeVisible();
  });

  test('valid checkout flow', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Full Checkout Test');
    await page.fill('#email', `fullcheckout${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
    
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    
    await page.goto('/checkout.html');
    await page.fill('#fullName', 'John Doe');
    await page.fill('#street', '123 Main St');
    await page.fill('#city', 'New York');
    await page.fill('#state', 'NY');
    await page.fill('#zipCode', '10001');
    await page.fill('#phone', '5551234567');
    await page.click('#place-order-btn');
    await expect(page).toHaveURL(/order-confirmation\.html/);
  });

  test('checkout validation - missing address', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Val Test');
    await page.fill('#email', `valtest${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await page.click('#place-order-btn');
    await expect(page.locator('#checkout-error')).toContainText(/fill|required/i);
  });

  test('order summary shows total', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Summary Test');
    await page.fill('#email', `summary${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await expect(page.locator('.cart-total')).toContainText('$');
  });
});
