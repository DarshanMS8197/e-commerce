import { test, expect } from '@playwright/test';

test.describe('Homepage', () => {
  test('homepage loads', async ({ page }) => {
    await page.goto('/index.html');
    await expect(page).toHaveTitle(/Zyphora/);
  });

  test('header has logo', async ({ page }) => {
    await page.goto('/index.html');
    await expect(page.locator('.logo')).toContainText('Zyphora');
  });

  test('header has cart', async ({ page }) => {
    await page.goto('/index.html');
    await expect(page.locator('.cart-btn')).toBeVisible();
  });

  test('footer links', async ({ page }) => {
    await page.goto('/index.html');
    await expect(page.locator('.footer a').first()).toBeVisible();
  });

  test('skip link for accessibility', async ({ page }) => {
    await page.goto('/index.html');
    await page.keyboard.press('Tab');
    await expect(page.locator('.skip-link')).toBeFocused();
  });

  test('navigation works', async ({ page }) => {
    await page.goto('/index.html');
    await page.click('a[href="cart.html"]');
    await expect(page).toHaveURL(/cart\.html/);
  });

  test('login link', async ({ page }) => {
    await page.goto('/index.html');
    await page.click('#login-link');
    await expect(page).toHaveURL(/login\.html/);
  });

  test('register link', async ({ page }) => {
    await page.goto('/index.html');
    await page.click('#register-link');
    await expect(page).toHaveURL(/register\.html/);
  });
});
