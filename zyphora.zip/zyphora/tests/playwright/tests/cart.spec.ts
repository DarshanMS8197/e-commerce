import { test, expect } from '@playwright/test';

test.describe('Cart', () => {
  test('add item to cart', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card', { timeout: 10000 });
    const addBtn = page.locator('.add-to-cart-btn').first();
    await addBtn.click();
    const count = await page.locator('#cart-count').textContent();
    expect(parseInt(count || '0')).toBeGreaterThan(0);
  });

  test('remove item from cart', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/cart.html');
    await page.locator('.remove-cart-item').first().click();
    await expect(page.locator('#cart-empty')).toBeVisible();
  });

  test('update quantity', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/cart.html');
    const plusBtn = page.locator('.cart-qty-plus').first();
    await plusBtn.click();
    const input = page.locator('.cart-qty').first();
    await expect(input).toHaveValue('2');
  });

  test('cart persistence - localStorage', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    const count1 = await page.locator('#cart-count').textContent();
    await page.goto('/login.html');
    const count2 = await page.locator('#cart-count').textContent();
    expect(count1).toBe(count2);
  });

  test('total calculation', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/cart.html');
    const total = page.locator('#cart-total');
    await expect(total).toContainText('$');
  });

  test('cart icon shows count', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.locator('.add-to-cart-btn').nth(1).click();
    const count = await page.locator('#cart-count').textContent();
    expect(parseInt(count || '0')).toBeGreaterThanOrEqual(2);
  });

  test('decrease quantity removes at zero', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/cart.html');
    const minusBtn = page.locator('.cart-qty-minus').first();
    await minusBtn.click();
    await minusBtn.click();
    await expect(page.locator('#cart-empty')).toBeVisible();
  });

  test('empty cart shows message', async ({ page }) => {
    await page.goto('/cart.html');
    await expect(page.locator('#cart-empty, .cart-item')).toBeVisible();
  });
});
