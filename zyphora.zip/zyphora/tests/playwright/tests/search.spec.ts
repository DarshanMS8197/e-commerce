import { test, expect } from '@playwright/test';

test.describe('Search', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/index.html');
  });

  test('valid search - finds products', async ({ page }) => {
    await page.fill('#search-input', 'wireless');
    await page.waitForSelector('.search-suggestions.visible', { timeout: 5000 }).catch(() => {});
    const suggestions = page.locator('.suggestion-item');
    await expect(suggestions.first()).toBeVisible({ timeout: 3000 });
  });

  test('no results search', async ({ page }) => {
    await page.fill('#search-input', 'xyznonexistent123');
    await page.waitForTimeout(500);
    const content = await page.locator('.search-suggestions').textContent();
    expect(content?.toLowerCase()).toMatch(/no results|found/i);
  });

  test('case insensitive search', async ({ page }) => {
    await page.fill('#search-input', 'ELECTRONICS');
    await page.waitForTimeout(500);
    const suggestions = page.locator('.suggestion-item');
    await expect(suggestions.first()).toBeVisible({ timeout: 3000 });
  });

  test('special characters in search', async ({ page }) => {
    await page.fill('#search-input', '!@#$%');
    await page.waitForTimeout(500);
    await expect(page.locator('.search-suggestions')).toBeVisible();
  });

  test('search triggers suggestions', async ({ page }) => {
    await page.fill('#search-input', 'shirt');
    await page.waitForTimeout(800);
    const visible = await page.locator('.search-suggestions.visible').count() > 0;
    expect(visible).toBeTruthy();
  });

  test('search minimum 2 characters', async ({ page }) => {
    await page.fill('#search-input', 'a');
    await page.waitForTimeout(500);
    const suggestions = page.locator('.search-suggestions.visible');
    await expect(suggestions).toHaveCount(0);
  });

  test('click suggestion navigates to product', async ({ page }) => {
    await page.fill('#search-input', 'headphones');
    await page.waitForTimeout(1000);
    const firstLink = page.locator('.suggestion-item a').first();
    if (await firstLink.count() > 0) {
      await firstLink.click();
      await expect(page).toHaveURL(/product-detail\.html/);
    }
  });

  test('escape closes suggestions', async ({ page }) => {
    await page.fill('#search-input', 'phone');
    await page.waitForTimeout(800);
    await page.keyboard.press('Escape');
    await expect(page.locator('.search-suggestions.visible')).toHaveCount(0);
  });
});
