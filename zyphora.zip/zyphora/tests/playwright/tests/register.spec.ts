import { test, expect } from '@playwright/test';

test.describe('Registration', () => {
  test('valid registration', async ({ page }) => {
    const email = `test${Date.now()}@zyphora.com`;
    await page.goto('/register.html');
    await page.fill('#name', 'Test User');
    await page.fill('#email', email);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
  });

  test('duplicate email', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'First User');
    await page.fill('#email', 'duplicate@zyphora.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/index\.html/);
    
    await page.goto('/register.html');
    await page.fill('#name', 'Second User');
    await page.fill('#email', 'duplicate@zyphora.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error')).toContainText(/already|registered/i);
  });

  test('weak password - less than 6 chars', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Test User');
    await page.fill('#email', `weak${Date.now()}@zyphora.com`);
    await page.fill('#password', '12345');
    await page.click('button[type="submit"]');
    await expect(page.locator('#password-error')).toContainText(/6|character/i);
  });

  test('empty name', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#email', `test${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#name-error')).toContainText(/required/i);
  });

  test('empty email', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Test User');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#email-error')).toContainText(/required/i);
  });

  test('invalid email format', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Test User');
    await page.fill('#email', 'notanemail');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error, #email-error')).toBeVisible();
  });
});
