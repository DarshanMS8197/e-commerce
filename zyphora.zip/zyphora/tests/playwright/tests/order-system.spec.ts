import { test, expect } from '@playwright/test';

test.describe('Order System', () => {
  test('order creation', async ({ page }) => {
    await page.goto('/register.html');
    const email = `order${Date.now()}@zyphora.com`;
    await page.fill('#name', 'Order User');
    await page.fill('#email', email);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await page.fill('#fullName', 'Jane Doe');
    await page.fill('#street', '456 Oak Ave');
    await page.fill('#city', 'Boston');
    await page.fill('#state', 'MA');
    await page.fill('#zipCode', '02101');
    await page.fill('#phone', '5559876543');
    await page.click('#place-order-btn');
    await expect(page).toHaveURL(/order-confirmation\.html/);
    await expect(page.locator('text=Order ID')).toBeVisible();
  });

  test('order history display', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'test@zyphora.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/my-orders.html');
    await expect(page.locator('.order-card, .loading')).toBeVisible();
  });

  test('track order page', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Track User');
    await page.fill('#email', `track${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await page.fill('#fullName', 'Track Doe');
    await page.fill('#street', '789 Elm St');
    await page.fill('#city', 'Chicago');
    await page.fill('#state', 'IL');
    await page.fill('#zipCode', '60601');
    await page.fill('#phone', '5551112233');
    await page.click('#place-order-btn');
    await page.waitForURL(/order-confirmation\.html/);
    await page.click('text=Track Order');
    await expect(page).toHaveURL(/track-order\.html/);
  });

  test('order details accuracy', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Details User');
    await page.fill('#email', `details${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await page.fill('#fullName', 'Details Doe');
    await page.fill('#street', '100 Pine Rd');
    await page.fill('#city', 'Seattle');
    await page.fill('#state', 'WA');
    await page.fill('#zipCode', '98101');
    await page.fill('#phone', '5554445566');
    await page.click('#place-order-btn');
    await page.waitForURL(/order-confirmation\.html/);
    await expect(page.locator('text=ZYP-')).toBeVisible();
    await expect(page.locator('text=$')).toBeVisible();
  });

  test('delivery estimate shown', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Est User');
    await page.fill('#email', `est${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    await page.goto('/checkout.html');
    await page.fill('#fullName', 'Est Doe');
    await page.fill('#street', '200 Maple Dr');
    await page.fill('#city', 'Denver');
    await page.fill('#state', 'CO');
    await page.fill('#zipCode', '80201');
    await page.fill('#phone', '5557778899');
    await page.click('#place-order-btn');
    await page.waitForURL(/order-confirmation\.html/);
    await expect(page.locator('text=Estimated')).toBeVisible();
  });

  test('my orders requires login', async ({ page }) => {
    await page.goto('/my-orders.html');
    await expect(page.locator('text=login')).toBeVisible();
  });

  test('track order requires login', async ({ page }) => {
    await page.goto('/track-order.html?id=ZYP-123');
    await expect(page).toHaveURL(/login\.html/);
  });

  test('order timeline displays stages', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', 'test@zyphora.com');
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/my-orders.html');
    await page.waitForSelector('.order-card, .loading', { timeout: 5000 });
    const trackBtn = page.locator('text=Track Order').first();
    if (await trackBtn.count() > 0) {
      await trackBtn.click();
      await expect(page.locator('.timeline-item, .timeline')).toBeVisible();
    }
  });
});
