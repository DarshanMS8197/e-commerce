import { test, expect } from '@playwright/test';

test.describe('Accessibility', () => {
  test('main content has heading', async ({ page }) => {
    await page.goto('/index.html');
    await expect(page.locator('#main-content')).toBeVisible();
  });

  test('forms have labels', async ({ page }) => {
    await page.goto('/login.html');
    await expect(page.locator('label[for="email"]')).toBeVisible();
    await expect(page.locator('label[for="password"]')).toBeVisible();
  });

  test('buttons have focus', async ({ page }) => {
    await page.goto('/index.html');
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    const focused = page.locator(':focus');
    await expect(focused).toBeVisible();
  });

  test('search has aria label', async ({ page }) => {
    await page.goto('/index.html');
    const search = page.locator('#search-input');
    await expect(search).toHaveAttribute('aria-label', /search/i);
  });

  test('cart link has aria label', async ({ page }) => {
    await page.goto('/index.html');
    const cart = page.locator('a[href="cart.html"].cart-btn');
    await expect(cart).toHaveAttribute('aria-label', /cart/i);
  });
});
