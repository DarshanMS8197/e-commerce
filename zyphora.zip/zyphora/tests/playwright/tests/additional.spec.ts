import { test, expect } from '@playwright/test';

test.describe('Additional Login Tests', () => {
  test('login page has correct title', async ({ page }) => {
    await page.goto('/login.html');
    await expect(page).toHaveTitle(/Login/);
  });
  test('login form has email and password fields', async ({ page }) => {
    await page.goto('/login.html');
    await expect(page.locator('#email')).toBeVisible();
    await expect(page.locator('#password')).toBeVisible();
  });
  test('login link to register', async ({ page }) => {
    await page.goto('/login.html');
    await page.click('a[href="register.html"]');
    await expect(page).toHaveURL(/register\.html/);
  });
  test('xss attempt in login', async ({ page }) => {
    await page.goto('/login.html');
    await page.fill('#email', '<script>alert(1)</script>@test.com');
    await page.fill('#password', 'pass123');
    await page.click('button[type="submit"]');
    await expect(page.locator('#form-error')).toBeVisible();
  });
});

test.describe('Additional Register Tests', () => {
  test('register page title', async ({ page }) => {
    await page.goto('/register.html');
    await expect(page).toHaveTitle(/Register/);
  });
  test('register link to login', async ({ page }) => {
    await page.goto('/register.html');
    await page.click('a[href="login.html"]');
    await expect(page).toHaveURL(/login\.html/);
  });
});

test.describe('Additional Cart Tests', () => {
  test('proceed to checkout disabled when empty', async ({ page }) => {
    await page.goto('/cart.html');
    await expect(page.locator('#cart-empty, .cart-item')).toBeVisible();
  });
  test('cart page title', async ({ page }) => {
    await page.goto('/cart.html');
    await expect(page).toHaveTitle(/Cart/);
  });
});

test.describe('Additional Product Tests', () => {
  test('product cards show price', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-price', { timeout: 10000 });
    await expect(page.locator('.product-price').first()).toContainText('$');
  });
  test('product cards show category', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-category', { timeout: 10000 });
    await expect(page.locator('.product-category').first()).toBeVisible();
  });
});

test.describe('Pagination', () => {
  test('pagination or product grid visible', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForTimeout(2000);
    const pagination = page.locator('#pagination');
    const grid = page.locator('.product-grid');
    await expect(pagination.or(grid)).toBeVisible();
  });
});
