import { test, expect } from '@playwright/test';

test.describe('Products', () => {
  test('product grid loads', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card, .loading', { timeout: 10000 });
    const cards = page.locator('.product-card');
    await expect(cards.first()).toBeVisible({ timeout: 5000 });
  });

  test('category filter', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('#category-filter', { timeout: 5000 });
    await page.selectOption('#category-filter', 'Electronics');
    await page.waitForTimeout(1000);
    const categoryLabels = page.locator('.product-category');
    const count = await categoryLabels.count();
    if (count > 0) {
      await expect(categoryLabels.first()).toContainText('Electronics');
    }
  });

  test('product detail page', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card-link', { timeout: 10000 });
    await page.locator('.product-card-link').first().click();
    await expect(page).toHaveURL(/product-detail\.html/);
    await expect(page.locator('.product-detail-price, .product-detail-info')).toBeVisible();
  });

  test('add to cart from product detail', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card-link', { timeout: 10000 });
    await page.locator('.product-card-link').first().click();
    await page.waitForSelector('.add-to-cart-detail', { timeout: 5000 });
    await page.click('.add-to-cart-detail');
    await expect(page.locator('text=Added')).toBeVisible();
  });

  test('quantity selector on product detail', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card-link', { timeout: 10000 });
    await page.locator('.product-card-link').first().click();
    await page.waitForSelector('#qty-plus', { timeout: 5000 });
    await page.click('#qty-plus');
    await page.click('#qty-plus');
    await expect(page.locator('#qty')).toHaveValue('3');
  });

  test('sort products', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('#sort-filter', { timeout: 5000 });
    await page.selectOption('#sort-filter', 'price-asc');
    await page.waitForTimeout(1500);
    const prices = await page.locator('.product-price').allTextContents();
    if (prices.length >= 2) {
      const p1 = parseFloat(prices[0].replace('$', ''));
      const p2 = parseFloat(prices[1].replace('$', ''));
      expect(p1).toBeLessThanOrEqual(p2);
    }
  });

  test('product images have alt text', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card img', { timeout: 10000 });
    const imgs = page.locator('.product-card img');
    const count = await imgs.count();
    for (let i = 0; i < Math.min(count, 5); i++) {
      const alt = await imgs.nth(i).getAttribute('alt');
      expect(alt).toBeTruthy();
    }
  });

  test('product grid responsive', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/index.html');
    await page.waitForSelector('.product-grid', { timeout: 10000 });
    const grid = page.locator('.product-grid');
    await expect(grid).toBeVisible();
  });
});
