import { test, expect } from '@playwright/test';

test.describe('Performance', () => {
  test('homepage load time', async ({ page }) => {
    const start = Date.now();
    await page.goto('/index.html');
    await page.waitForSelector('.product-card, .loading', { timeout: 15000 });
    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(10000);
  });

  test('product page load time', async ({ page }) => {
    await page.goto('/index.html');
    await page.waitForSelector('.product-card-link', { timeout: 10000 });
    const start = Date.now();
    await page.locator('.product-card-link').first().click();
    await page.waitForSelector('.product-detail-price, .product-detail-info', { timeout: 5000 });
    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(5000);
  });

  test('checkout page load time', async ({ page }) => {
    await page.goto('/register.html');
    await page.fill('#name', 'Perf Test');
    await page.fill('#email', `perf${Date.now()}@zyphora.com`);
    await page.fill('#password', 'password123');
    await page.click('button[type="submit"]');
    await page.goto('/index.html');
    await page.waitForSelector('.add-to-cart-btn', { timeout: 10000 });
    await page.locator('.add-to-cart-btn').first().click();
    const start = Date.now();
    await page.goto('/checkout.html');
    await page.waitForSelector('#fullName, #checkout-content', { timeout: 5000 });
    const loadTime = Date.now() - start;
    expect(loadTime).toBeLessThan(5000);
  });
});
