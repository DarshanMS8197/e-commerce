package com.zyphora;

import io.qameta.allure.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Epic("Zyphora E-commerce")
@Feature("Search")
public class SearchTest extends BaseTest {

    @Test(description = "Valid search")
    @Severity(SeverityLevel.CRITICAL)
    public void validSearch() {
        driver.get(BASE_URL + "/index.html");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.findElement(By.id("search-input")).sendKeys("wireless");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        boolean hasSuggestions = driver.findElements(By.cssSelector(".search-suggestions.visible")).size() > 0;
        Assert.assertTrue(hasSuggestions || driver.findElements(By.cssSelector(".suggestion-item")).size() > 0);
    }

    @Test(description = "Case insensitive search")
    @Severity(SeverityLevel.NORMAL)
    public void caseInsensitiveSearch() {
        driver.get(BASE_URL + "/index.html");
        driver.findElement(By.id("search-input")).sendKeys("ELECTRONICS");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        boolean hasContent = driver.findElement(By.id("search-suggestions")).getAttribute("class").contains("visible") ||
            driver.findElements(By.cssSelector(".suggestion-item")).size() > 0;
        Assert.assertTrue(hasContent);
    }
}
