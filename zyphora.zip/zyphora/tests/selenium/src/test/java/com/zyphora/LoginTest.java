package com.zyphora;

import io.qameta.allure.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

@Epic("Zyphora E-commerce")
@Feature("Login")
public class LoginTest extends BaseTest {

    @Test(description = "Valid login")
    @Severity(SeverityLevel.CRITICAL)
    public void validLogin() {
        driver.get(BASE_URL + "/login.html");
        driver.findElement(By.id("email")).sendKeys("test@zyphora.com");
        driver.findElement(By.id("password")).sendKeys("password123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("index.html"));
    }

    @Test(description = "Invalid login - wrong password")
    @Severity(SeverityLevel.NORMAL)
    public void invalidLoginWrongPassword() {
        driver.get(BASE_URL + "/login.html");
        driver.findElement(By.id("email")).sendKeys("test@zyphora.com");
        driver.findElement(By.id("password")).sendKeys("wrongpassword");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        WebElement error = driver.findElement(By.id("form-error"));
        Assert.assertTrue(error.getText().toLowerCase().contains("invalid") ||
            error.getText().toLowerCase().contains("failed"));
    }

    @Test(description = "Empty email field")
    @Severity(SeverityLevel.NORMAL)
    public void emptyEmailField() {
        driver.get(BASE_URL + "/login.html");
        driver.findElement(By.id("password")).sendKeys("password123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        WebElement error = driver.findElement(By.id("email-error"));
        Assert.assertTrue(error.getText().toLowerCase().contains("required"));
    }

    @Test(description = "Empty password field")
    @Severity(SeverityLevel.NORMAL)
    public void emptyPasswordField() {
        driver.get(BASE_URL + "/login.html");
        driver.findElement(By.id("email")).sendKeys("test@zyphora.com");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        WebElement error = driver.findElement(By.id("password-error"));
        Assert.assertTrue(error.getText().toLowerCase().contains("required"));
    }

    @Test(description = "SQL injection attempt")
    @Severity(SeverityLevel.CRITICAL)
    public void sqlInjectionAttempt() {
        driver.get(BASE_URL + "/login.html");
        driver.findElement(By.id("email")).sendKeys("admin'--");
        driver.findElement(By.id("password")).sendKeys("password' OR '1'='1");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        WebElement error = driver.findElement(By.id("form-error"));
        Assert.assertTrue(error.isDisplayed());
    }
}
