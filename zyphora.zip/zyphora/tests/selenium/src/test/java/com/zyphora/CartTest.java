package com.zyphora;

import io.qameta.allure.*;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Epic("Zyphora E-commerce")
@Feature("Shopping Cart")
public class CartTest extends BaseTest {

    @Test(description = "Add item to cart")
    @Severity(SeverityLevel.CRITICAL)
    public void addItemToCart() {
        driver.get(BASE_URL + "/index.html");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".add-to-cart-btn")));
        driver.findElement(By.cssSelector(".add-to-cart-btn")).click();
        String count = driver.findElement(By.id("cart-count")).getText();
        Assert.assertTrue(Integer.parseInt(count) > 0);
    }

    @Test(description = "Cart total calculation")
    @Severity(SeverityLevel.NORMAL)
    public void cartTotalCalculation() {
        driver.get(BASE_URL + "/index.html");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".add-to-cart-btn")));
        driver.findElement(By.cssSelector(".add-to-cart-btn")).click();
        driver.get(BASE_URL + "/cart.html");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cart-total")));
        String total = driver.findElement(By.id("cart-total")).getText();
        Assert.assertTrue(total.contains("$"));
    }

    @Test(description = "Remove item from cart")
    @Severity(SeverityLevel.NORMAL)
    public void removeItemFromCart() {
        driver.get(BASE_URL + "/index.html");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".add-to-cart-btn")));
        driver.findElement(By.cssSelector(".add-to-cart-btn")).click();
        driver.get(BASE_URL + "/cart.html");
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".remove-cart-item")));
        driver.findElement(By.cssSelector(".remove-cart-item")).click();
        Assert.assertTrue(driver.findElement(By.id("cart-empty")).isDisplayed());
    }
}
