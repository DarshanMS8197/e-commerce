/**
 * Zyphora - Homepage Load Performance
 * Run: k6 run homepage.js
 */
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.FRONTEND_URL || 'http://localhost:3000';

export const options = {
  vus: 10,
  duration: '30s',
  thresholds: {
    http_req_duration: ['p(95)<3000']
  }
};

export default function () {
  const res = http.get(`${BASE_URL}/index.html`);
  check(res, { 'homepage status 200': (r) => r.status === 200 });
  sleep(2);
}
