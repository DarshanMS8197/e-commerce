/**
 * Zyphora - Search with Suggestions
 */
const Search = {
  debounceTimer: null,

  init() {
    const input = document.getElementById('search-input');
    const suggestions = document.getElementById('search-suggestions');
    
    if (!input || !suggestions) return;
    
    input.addEventListener('input', () => this.handleInput(input, suggestions));
    input.addEventListener('focus', () => this.handleInput(input, suggestions));
    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !suggestions.contains(e.target)) {
        suggestions.classList.remove('visible');
      }
    });
    
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') suggestions.classList.remove('visible');
    });
  },

  async handleInput(input, suggestions) {
    clearTimeout(this.debounceTimer);
    const q = input.value.trim();
    
    if (q.length < 2) {
      suggestions.classList.remove('visible');
      suggestions.innerHTML = '';
      return;
    }
    
    this.debounceTimer = setTimeout(async () => {
      try {
        const { data } = await API.get(`/products/search/suggestions?q=${encodeURIComponent(q)}`);
        this.renderSuggestions(suggestions, data, q);
      } catch {
        suggestions.classList.remove('visible');
      }
    }, 300);
  },

  renderSuggestions(container, products, query) {
    if (!products || !products.length) {
      container.innerHTML = '<div class="suggestion-item">No results found</div>';
      container.classList.add('visible');
      return;
    }
    
    container.innerHTML = products.slice(0, 8).map(p => `
      <a href="product-detail.html?id=${p._id}" class="suggestion-item" role="option">
        <img src="${p.image}" alt="" width="48" height="48" loading="lazy">
        <div>
          <div><strong>${p.name}</strong></div>
          <div style="font-size:0.85rem;color:var(--text-muted)">${p.category} - $${p.price.toFixed(2)}</div>
        </div>
      </a>
    `).join('');
    container.classList.add('visible');
  }
};
