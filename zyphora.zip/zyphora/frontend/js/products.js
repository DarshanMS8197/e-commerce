/**
 * Zyphora - Products Module
 */
const Products = {
  async loadCategories() {
    const { data } = await API.get('/products/categories');
    const select = document.getElementById('category-filter');
    if (!select) return;
    
    data.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat;
      opt.textContent = cat;
      select.appendChild(opt);
    });
  },

  async loadProducts(page = 1) {
    const params = new URLSearchParams(window.location.search);
    const category = document.getElementById('category-filter')?.value || params.get('category') || 'all';
    const sort = document.getElementById('sort-filter')?.value || params.get('sort') || '';
    const search = document.getElementById('search-input')?.value || params.get('search') || '';
    
    let endpoint = `/products?page=${page}&limit=24`;
    if (category !== 'all') endpoint += `&category=${encodeURIComponent(category)}`;
    if (sort) endpoint += `&sort=${sort}`;
    if (search) endpoint += `&search=${encodeURIComponent(search)}`;
    
    const { data, pagination } = await API.get(endpoint);
    return { products: data, pagination };
  },

  renderProduct(product) {
    return `
      <article class="product-card" role="listitem">
        <a href="product-detail.html?id=${product._id}" class="product-card-link">
          <div class="product-image">
            <img src="${product.image}" alt="${product.name}" loading="lazy" width="400" height="400">
          </div>
          <div class="product-info">
            <span class="product-category">${product.category}</span>
            <h3 class="product-name">${product.name}</h3>
            <div class="product-rating" aria-label="Rating ${product.rating} out of 5">
              <span>★</span> ${product.rating}
            </div>
            <span class="product-price">$${product.price.toFixed(2)}</span>
          </div>
        </a>
        <button type="button" class="add-to-cart-btn" data-product-id="${product._id}" data-product='${JSON.stringify({ _id: product._id, name: product.name, price: product.price, image: product.image })}'>
          Add to Cart
        </button>
      </article>
    `;
  },

  renderGrid(products) {
    const grid = document.getElementById('product-grid');
    if (!grid) return;
    
    if (!products.length) {
      grid.innerHTML = '<p class="loading">No products found. Try adjusting your filters.</p>';
      return;
    }
    
    grid.innerHTML = products.map(p => this.renderProduct(p)).join('');
    
    grid.querySelectorAll('.add-to-cart-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const productId = btn.dataset.productId;
        let product = null;
        try {
          product = JSON.parse(btn.dataset.product);
        } catch {}
        Cart.addItem(productId, 1, product);
        btn.textContent = 'Added!';
        setTimeout(() => { btn.textContent = 'Add to Cart'; }, 1500);
      });
    });
  },

  renderPagination(pagination) {
    const nav = document.getElementById('pagination');
    if (!nav || !pagination || pagination.pages <= 1) {
      if (nav) nav.innerHTML = '';
      return;
    }
    
    const params = new URLSearchParams(window.location.search);
    let html = '';
    if (pagination.page > 1) {
      params.set('page', String(pagination.page - 1));
      html += `<a href="?${params}" class="btn btn-secondary">Previous</a> `;
    }
    html += `<span>Page ${pagination.page} of ${pagination.pages}</span>`;
    if (pagination.page < pagination.pages) {
      params.set('page', String(pagination.page + 1));
      html += ` <a href="?${params}" class="btn btn-secondary mt-1">Next</a>`;
    }
    nav.innerHTML = html;
  }
};
