/**
 * Zyphora - Configuration
 */
const CONFIG = {
  API_BASE_URL: 'http://localhost:5000/api',
  CART_STORAGE_KEY: 'zyphora_cart',
  TOKEN_STORAGE_KEY: 'zyphora_token',
  USER_STORAGE_KEY: 'zyphora_user'
};
