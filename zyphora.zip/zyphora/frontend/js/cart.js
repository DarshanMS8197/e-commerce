/**
 * Zyphora - Shopping Cart
 */
const Cart = {
  getItems() {
    try {
      return JSON.parse(localStorage.getItem(CONFIG.CART_STORAGE_KEY) || '[]');
    } catch {
      return [];
    }
  },

  setItems(items) {
    localStorage.setItem(CONFIG.CART_STORAGE_KEY, JSON.stringify(items));
    this.updateCount();
  },

  addItem(productId, quantity = 1, product = null) {
    const items = this.getItems();
    const existing = items.find(i => i.productId === productId);
    
    if (existing) {
      existing.quantity += quantity;
    } else {
      items.push({
        productId,
        quantity,
        name: product?.name,
        price: product?.price,
        image: product?.image
      });
    }
    this.setItems(items);
  },

  removeItem(productId) {
    const items = this.getItems().filter(i => i.productId !== productId);
    this.setItems(items);
  },

  updateQuantity(productId, quantity) {
    const items = this.getItems();
    const item = items.find(i => i.productId === productId);
    if (!item) return;
    
    if (quantity <= 0) {
      this.removeItem(productId);
      return;
    }
    item.quantity = quantity;
    this.setItems(items);
  },

  getTotal() {
    return this.getItems().reduce((sum, i) => sum + (i.price * i.quantity), 0);
  },

  getCount() {
    return this.getItems().reduce((sum, i) => sum + i.quantity, 0);
  },

  clear() {
    this.setItems([]);
  },

  updateCount() {
    const el = document.getElementById('cart-count');
    if (el) el.textContent = this.getCount();
  }
};
