/**
 * Zyphora - Authentication
 */
const Auth = {
  isLoggedIn() {
    return !!localStorage.getItem(CONFIG.TOKEN_STORAGE_KEY);
  },

  getUser() {
    try {
      return JSON.parse(localStorage.getItem(CONFIG.USER_STORAGE_KEY));
    } catch {
      return null;
    }
  },

  setUser(token, user) {
    localStorage.setItem(CONFIG.TOKEN_STORAGE_KEY, token);
    localStorage.setItem(CONFIG.USER_STORAGE_KEY, JSON.stringify(user));
  },

  logout() {
    localStorage.removeItem(CONFIG.TOKEN_STORAGE_KEY);
    localStorage.removeItem(CONFIG.USER_STORAGE_KEY);
  },

  updateNav() {
    const authNav = document.getElementById('auth-nav');
    const userNav = document.getElementById('user-nav');
    const loginLink = document.getElementById('login-link');
    const registerLink = document.getElementById('register-link');
    
    if (!authNav || !userNav) return;
    
    if (this.isLoggedIn()) {
      authNav.style.display = 'none';
      userNav.style.display = 'inline-flex';
      userNav.style.alignItems = 'center';
      userNav.style.gap = '16px';
      
      const logoutBtn = document.getElementById('logout-btn');
      if (logoutBtn) {
        logoutBtn.onclick = () => {
          this.logout();
          window.location.href = 'index.html';
        };
      }
    } else {
      authNav.style.display = 'inline';
      userNav.style.display = 'none';
    }
  }
};
