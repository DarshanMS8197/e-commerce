/**
 * Zyphora - Main App
 */
document.addEventListener('DOMContentLoaded', async () => {
  Auth.updateNav();
  Cart.updateCount();
  Search.init();
  
  await Products.loadCategories();
  
  const params = new URLSearchParams(window.location.search);
  const category = params.get('category');
  if (category) {
    const select = document.getElementById('category-filter');
    if (select) select.value = category;
  }
  
  const select = document.getElementById('category-filter');
  const sortSelect = document.getElementById('sort-filter');
  
  const load = async () => {
    const params = new URLSearchParams(window.location.search);
    const page = parseInt(params.get('page')) || 1;
    const grid = document.getElementById('product-grid');
    grid.innerHTML = '<div class="loading">Loading products...</div>';
    
    try {
      const { products, pagination } = await Products.loadProducts(page);
      Products.renderGrid(products);
      Products.renderPagination(pagination);
    } catch (err) {
      grid.innerHTML = `<p class="loading">Failed to load products. Make sure the API is running.</p>`;
    }
  };
  
  if (select) select.addEventListener('change', load);
  if (sortSelect) sortSelect.addEventListener('change', load);
  
  await load();
});
